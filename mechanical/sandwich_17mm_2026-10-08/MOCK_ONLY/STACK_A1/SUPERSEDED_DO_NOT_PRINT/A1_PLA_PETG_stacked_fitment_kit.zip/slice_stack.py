"""Local Bambu Studio slicing; no printer operations."""
from pathlib import Path
import json,subprocess,sys,shutil
HERE=Path(__file__).resolve().parent
BASE=HERE.parent/'PRINT_A1'
name=sys.argv[1] if len(sys.argv)>1 else 'stacked_kit'
job=HERE/'jobs'/name;job.mkdir(parents=True,exist_ok=True)
args=['D:/Bambu Studio/bambu-studio.exe','--load-settings',str(BASE/'presets/printer.json')+';'+str(HERE/'presets/stack.json'),
 '--load-filaments',str(HERE/'presets/PLA.json')+';'+str(HERE/'presets/PETG_interface.json'),'--curr-bed-type','Textured PEI Plate','--arrange','0',
 '--slice','0','--debug','2','--outputdir',str(job),'--export-3mf','sliced.3mf',str(HERE/(name+'.3mf'))]
r=subprocess.run(args,capture_output=True,text=True)
(job/'cli.log').write_text(r.stdout+r.stderr,encoding='utf-8')
result=json.loads((job/'result.json').read_text())
print(json.dumps({'exit_code':r.returncode,'result':{k:v for k,v in result.items() if k!='sliced_plates'},'plates':[
 {k:v for k,v in p.items() if k not in ('objects','feature_type_times')} for p in result.get('sliced_plates',[])]},indent=2))
if result['return_code']==0:shutil.copyfile(job/'sliced.3mf',HERE/(name+'.gcode.3mf'))
else:raise SystemExit(1)
