"""Package the verified stack without disposable slicer working files."""
from pathlib import Path
import json,zipfile,hashlib
HERE=Path(__file__).resolve().parent

def main():
    v=json.loads((HERE/'review/stack-verification.json').read_text())
    assert not v['failures']
    m=json.loads((HERE/'stack-manifest.json').read_text())
    r=json.loads((HERE/'review/stacked_kit-slice.json').read_text())['sliced_plates'][0]
    t=json.loads((HERE/'review/separator_trial-slice.json').read_text())['sliced_plates'][0]
    text=f'''# A1 single-job fitment kit — PLA with PETG support contacts

Updated 23 October 2026. Bambu **A1 / AMS Lite**, 256 × 256 mm, **0.4 mm nozzle**. One build plate, 105 unchanged components: 24 quarter-panel sections and 81 smaller parts, including 19 optional gauges/envelopes. This is an **unpowered fitment mock**, not finished enclosure hardware.

## Open these files

1. **Quality/separation trial first:** [separator_trial.gcode.3mf](separator_trial.gcode.3mf), or [editable separator_trial.3mf](separator_trial.3mf). Six parts: two stacked screen frames, two stacked 0.5 mm washers, one option cap and one screen post. Both pairs use the same 1 mm supported interval as the full job. About **{sum(f['total_used_g'] for f in t['filaments']):.1f} g total / {t['total_predication']/60:.0f} min**. The geometry-only trial needs the supplied presets if re-sliced; the sliced file already includes them.
2. **Complete editable project:** [stacked_kit_project.3mf](stacked_kit_project.3mf). Includes native Studio settings and 105 individually named parts in one multipart assembly. Open this to review or adjust the project. **Keep the assembly container:** Split to Objects, Auto Arrange, Drop to Bed or reorientation would destroy the vertical placements. Bambu drops independent floating objects to the bed; the assembly container preserves Z. The meshes have not been boolean-fused.
3. **Complete prepared slice:** [stacked_kit.gcode.3mf](stacked_kit.gcode.3mf). One A1 plate. Estimated **{r['total_predication']/3600:.1f} h**, **{r['filaments'][0]['total_used_g']:.0f} g PLA + {r['filaments'][1]['total_used_g']:.0f} g PETG**, including purge and prime tower; **{r['filament_change_times']} AMS changes**. These are slicer predictions, not observed printer consumption.
4. **Download package:** [A1_PLA_PETG_stacked_fitment_kit.zip](A1_PLA_PETG_stacked_fitment_kit.zip). [Individual per-part fallback](../PRINT_A1/README.md) remains available and uses less material/time overall when printed separately.

The [geometry-only stack](stacked_kit.3mf) is also supplied for CAD import; use the native project above to retain all slicing settings. Nothing was uploaded to a printer or started.

## Supports and AMS mapping

| Setting | Prepared value |
|---|---|
| Model parts / support scaffold | Filament 1, ordinary PLA |
| Support top and bottom contact layers | Filament 2, ordinary PETG; 2 layers on each face |
| Layer / first layer | 0.10 / 0.10 mm |
| Nominal separation between stacked parts | At least 1.00 mm, filled with support; not an empty air gap |
| Contact Z gap / interface line spacing | 0 mm top and bottom / 0 mm top and bottom |
| Support style | Normal automatic, allowed to start on earlier models |
| Scaffold spacing / interface speed | 3 mm / 80 mm/s |
| Initial support expansion / object brim | 1.5 mm / 3 mm |
| Walls / sparse infill | Arachne, 2 walls / 10% |
| Solid skins | Top 4 layers / 0.4 mm minimum; bottom 3 layers / 0.3 mm minimum |
| Outer / inner walls | 100 / 200 mm/s; acceleration 2,000 / 4,000 mm/s² |
| Small perimeters / top surface | 35 mm/s with 6 mm threshold / 80 mm/s |
| First-layer wall / infill speeds | 30 / 50 mm/s |
| Prime tower / travel speed caps | 120 / 500 mm/s |
| Filament temperature / maximum volumetric speed | Bambu PLA Basic 220 °C / 21 mm³/s; conservative Bambu PETG interface 245 °C / 8 mm³/s |
| Textured PEI bed | 65 °C for both; PETG is an elevated interface, not bed-contact material |
| Material change | Prime tower enabled; 800 mm³ flush each direction at 245 °C |
| Flush into model, infill or scaffold | Disabled |

Map the **PLA palette entry to the actual PLA AMS Lite slot**, and **PETG to its actual PETG slot** when opening the print dialog. Palette numbers are not a claim that particular spools are loaded. Bambu brand is confirmed; PETG Basic versus HF remains unknown. PLA uses the installed Bambu PLA Basic preset. PETG uses a conservative custom profile with their common 0.94 flow ratio, a selected 245 °C temperature and an 8 mm³/s cap; its generic PETG ID avoids falsely declaring a specific grade. Verify the labels and use dry, unfilled filament. Allow at least 750 g PLA and 250 g PETG for the job, trial and margin. A fresh 1 kg PLA spool plus 300 g PETG is a comfortable alternative if remaining weights are uncertain.

The [parameter comparison and tuning rationale](review/TUNING.md) records three fresh candidate slices. The selected profile retains uniform 0.10 mm model layers; variable layers saved only another 32 minutes before the interface-speed change. Flow ratio, pressure compensation and purge adequacy have not been calibrated on the physical printer.

PETG is used for **support contact faces**, with PLA in the bulk scaffold to limit changes and waste. Each upper part is supported on PETG, and support beginning on lower parts also has a PETG interface. This is not an all-PETG support tower.

Before starting, confirm A1, installed 0.4 mm nozzle, Textured PEI plate and correct material mapping. Keep the plate clear and observe the first layer. The trial must release without damaging frames or washers; measure their thicknesses, check the post seat/bore and test the option-cap guide before committing to the large stack. PETG/PLA adhesion, purge sufficiency and support scars need that physical trial. The prepared slice retains Bambu's bed-temperature/cooling and traditional-timelapse advisories; timelapse is not part of this job. The installed 2.7.1.62 slicer also has a reported supported-first-layer bridge issue, covered in the review.

## Geometry and assembly review

Read [review/REVIEW.md](review/REVIEW.md) for the per-group review, actual sliced support volume, optimization comparison, nine assembly checks and remaining fitment limits. [Print-group views](review/tier-contact-sheet.png), [stack heights](review/stack-heights.png), [numbered filename index](review/part-index.csv) and [machine-readable checks](review/stack-verification.json) are included. The independent [file inspection](review/file-inspection.json) passed for the declared A1 and materials; it does not check the physical printer or loaded spools.

The source meshes are watertight, source hashes match, placement bounds do not collide, and every elevated part has PETG interface paths below its footprint. Six oversized originals are represented only by their four quarter-sections each, with no scaling. Reconstruct them on a flat jig using original coordinates from [the source manifest](../manifest.json), then tape rear faces temporarily. Quarter seams do not reproduce full-panel stiffness.

Remove supports **from the top down**. Keep thin panels flat while peeling PETG; do not lever against washer edges, switch clips or collar membranes. Keep numbered parts organized using the CSV. Trial the real switch, screen, PCB, ports and hardware after the mock.

Some deliberately thin washers, pad/foam gauges, caps and collars fall below conservative FDM wall guidelines; a successful slice does not guarantee these details. Use the existing per-part fine-nozzle fallback if they fail. Rigid PLA collars cannot qualify TPU sealing or PCB compliance. The mock PCB omits most packages/solder and the OLED mock omits glass/header topography. Heatsink rear-retainer thread engagement and actual dongle body setback remain physical fitment concerns described in the review. **Never power the board with a plastic heatsink or rigid thermal-pad gauge.**

## Rebuild

The scripts use the existing project CAD Python environment and installed Bambu Studio; no printer connection is used. Run `build_stack.py`, then `slice_stack.py` for the full kit and `slice_stack.py separator_trial` for the trial, followed by `verify_stack.py`, the CAD plugin DfAM measurements, `make_review.py` and `package_stack.py`. They reference the retained original mock STLs and per-part preset helpers in the project. The ZIP is a print/review handoff, not a standalone source-model repository.

Sources and technique rationale are linked inside the [review](review/REVIEW.md), including [Prusa's support guide](https://help.prusa3d.com/article/support-material_1698) and [Bambu Studio's support configuration](https://github.com/bambulab/BambuStudio/blob/master/src/libslic3r/PrintConfig.cpp).
'''
    materials=json.loads((HERE/'review/material-breakdown.json').read_text())
    breakdown='## Material breakdown, including purges\n\n| Category | PLA | PETG | Total |\n|---|---:|---:|---:|\n'
    for row in materials['categories']:
        label=row['category'].replace(' (inferred remainder)','')
        breakdown+=f'| {label} | {row["PLA_g"]:.1f} g | {row["PETG_g"]:.1f} g | {row["total_g"]:.1f} g |\n'
    totals=materials['job_totals_g'];trial_g=materials['trial_totals_g'];combined=materials['full_job_plus_trial_g']
    breakdown+=f'| **Full job** | **{totals["PLA"]:.1f} g** | **{totals["PETG"]:.1f} g** | **{sum(totals.values()):.1f} g** |\n\n'
    breakdown+=f'The six-part trial adds **{trial_g["PLA"]:.1f} g PLA / {trial_g["PETG"]:.1f} g PETG**; full job plus one trial is **{combined["PLA"]:.1f} g PLA / {combined["PETG"]:.1f} g PETG**. '
    breakdown+='Prime-tower material is counted separately from purges. Purge is the inferred remainder after subtracting main deposition and measured tower extrusion from the slicer total. These are estimates; startup/calibration, cleaning and failures can add consumption. See [the accounting method and spool allowance](review/TUNING.md) and [material data](review/material-breakdown.json).\n\n'
    text=text.replace('## Supports and AMS mapping',breakdown+'## Supports and AMS mapping')
    (HERE/'README.md').write_text(text,encoding='utf-8')
    # Keep complete local presets beside the handoff for explicit profile review.
    import shutil
    for filename in ('printer.json',):
        shutil.copyfile(HERE.parent/'PRINT_A1/presets'/filename,HERE/'presets'/filename)
    files=[p for p in HERE.rglob('*') if p.is_file() and 'jobs' not in p.relative_to(HERE).parts and '__pycache__' not in p.relative_to(HERE).parts and p.suffix!='.zip' and p.name!='checksums.sha256']
    (HERE/'checksums.sha256').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(HERE).as_posix() for p in sorted(files)),encoding='utf-8')
    archive=HERE/'A1_PLA_PETG_stacked_fitment_kit.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,strict_timestamps=False) as z:
        for p in files+[HERE/'checksums.sha256']:z.write(p,p.relative_to(HERE))
    print(json.dumps({'package':str(archive),'bytes':archive.stat().st_size,'hours':r['total_predication']/3600,'PLA_g':r['filaments'][0]['total_used_g'],'PETG_g':r['filaments'][1]['total_used_g']},indent=2))

if __name__=='__main__':main()
