"""Inspect saved geometry, material settings and deposited support toolpaths.

This is file-only validation; it never contacts a printer.
"""
from pathlib import Path
import json,zipfile,hashlib,re,math,collections,xml.etree.ElementTree as ET
import numpy as np
HERE=Path(__file__).resolve().parent
KIT=HERE.parent
NS={'m':'http://schemas.microsoft.com/3dmanufacturing/core/2015/02'}

def deposited_paths(path):
    totals=collections.defaultdict(float);layers=collections.defaultdict(list)
    bounds=collections.defaultdict(lambda:[999.,999.,-999.,-999.])
    filament=0;feature='Custom';xy=[0.,0.];z=0.;relative=True;last_e=0.
    with zipfile.ZipFile(path) as archive:
        entry=next(n for n in archive.namelist() if n.endswith('plate_1.gcode'))
        for line in archive.open(entry):
            if line.startswith(b'; FEATURE:'):feature=line[11:].strip().decode();continue
            if line.startswith(b'; Z_HEIGHT:'):z=float(line.split(b':')[1]);continue
            if re.fullmatch(rb'T[0-9]+\s*',line):
                n=int(line[1:]);filament=n if n<2 else filament
            if line.startswith(b'M83'):relative=True
            elif line.startswith(b'M82'):relative=False
            elif line.startswith(b'G92 E'):last_e=float(line.split(b'E')[1].split()[0])
            if not line.startswith((b'G0 ',b'G1 ',b'G2 ',b'G3 ')):continue
            vals={k.decode():float(v) for k,v in re.findall(rb'([XYE])([-+\d.]+)',line.split(b';')[0])}
            nx,ny=vals.get('X',xy[0]),vals.get('Y',xy[1]);ex=vals.get('E',0.)
            if not relative:
                ex=vals.get('E',last_e)-last_e;last_e=vals.get('E',last_e)
            if ex>0 and ('X' in vals or 'Y' in vals) and math.hypot(nx-xy[0],ny-xy[1])>0.0001:
                totals[(feature,filament)]+=ex*math.pi*(1.75/2)**2
                b=bounds[feature]
                b[0]=min(b[0],xy[0],nx);b[1]=min(b[1],xy[1],ny)
                b[2]=max(b[2],xy[0],nx);b[3]=max(b[3],xy[1],ny)
                if feature!='Custom':layers[round(z,3)].append((feature,filament,xy[0],xy[1],nx,ny))
            xy=[nx,ny]
    return totals,layers,dict(bounds)

def native_names_and_project(name,parts):
    source=HERE/(name+'.gcode.3mf')
    with zipfile.ZipFile(source) as z:contents={n:z.read(n) for n in z.namelist()}
    config=ET.fromstring(contents['Metadata/model_settings.config'])
    native=config.findall('object/part')
    assert len(native)==len(parts)
    for el,p in zip(native,parts):
        el.find("metadata[@key='name']").set('value',f'T{p.get("tier",0):02d}_{p["name"]}')
    new_config=ET.tostring(config,encoding='utf-8',xml_declaration=True)
    changed=new_config!=contents['Metadata/model_settings.config']
    contents['Metadata/model_settings.config']=new_config
    if changed:
        with zipfile.ZipFile(source,'w',zipfile.ZIP_DEFLATED) as z:
            for n,b in contents.items():z.writestr(n,b)
    return contents,config

def saved_mesh_bounds(contents):
    """Use actual 3MF component transforms, not source-import history matrices."""
    models={};out={}
    def model(path):
        if path not in models:models[path]=ET.fromstring(contents[path])
        return models[path]
    def matrix(value):
        raw=np.array(list(map(float,value.split()))).reshape(4,3) if value else np.vstack((np.eye(3),[0,0,0]))
        result=np.eye(4);result[:3,:3]=raw[:3].T;result[:3,3]=raw[3];return result
    def walk(path,oid,transform):
        root=model(path);obj=root.find("m:resources/m:object[@id='"+oid+"']",NS)
        mesh=obj.find('m:mesh',NS)
        if mesh is not None:
            pts=np.array([[float(v.get(k)) for k in 'xyz'] for v in mesh.findall('m:vertices/m:vertex',NS)])
            pts=pts@transform[:3,:3].T+transform[:3,3]
            out[oid]=np.array([pts.min(axis=0),pts.max(axis=0)])
        else:
            for component in obj.findall('m:components/m:component',NS):
                target=component.get('{http://schemas.microsoft.com/3dmanufacturing/production/2015/06}path',path).lstrip('/')
                walk(target,component.get('objectid'),transform@matrix(component.get('transform')))
    for item in model('3D/3dmodel.model').findall('m:build/m:item',NS):
        walk('3D/3dmodel.model',item.get('objectid'),matrix(item.get('transform')))
    return out

def main():
    manifest=json.loads((HERE/'stack-manifest.json').read_text());parts=manifest['parts']
    lo=[];hi=[];fail=[]
    for i,p in enumerate(parts):
        p['index']=i+1
        if hashlib.sha256((KIT/p['source']).read_bytes()).hexdigest()!=p['sha256']:fail.append('source hash '+p['name'])
        lo.append([p['x'],p['y'],p['z']]);hi.append([p['x']+p['footprint_mm'][0],p['y']+p['footprint_mm'][1],p['z']+p['size_mm'][2]])
    a,b=np.array(lo),np.array(hi);separations=[]
    for i in range(len(parts)):
        for j in range(i):
            xy_overlap=np.all(np.minimum(b[i,:2],b[j,:2])-np.maximum(a[i,:2],a[j,:2])>1e-4)
            if xy_overlap:
                dz=max(a[i,2]-b[j,2],a[j,2]-b[i,2]);separations.append(float(dz))
                if dz<manifest['gap_mm']-1e-4:fail.append('separation '+parts[i]['name']+' '+parts[j]['name'])
    root=ET.fromstring(zipfile.ZipFile(HERE/'stacked_kit.3mf').read('3D/3dmodel.model'))
    tuning_file=HERE/'review/parameter-tuning.json'
    geometry_hash=hashlib.sha256(zipfile.ZipFile(HERE/'stacked_kit.3mf').read('3D/3dmodel.model')).hexdigest()
    if tuning_file.exists():
        original=json.loads(tuning_file.read_text()).get('original_geometry_xml_sha256')
        if original and original!=geometry_hash:fail.append('input geometry changed during parameter tuning')
    leaves=root.findall('m:resources/m:object/m:mesh',NS)
    assert len(leaves)==105 and len(root.findall('m:build/m:item',NS))==1
    contents,config=native_names_and_project('stacked_kit',parts)
    settings=json.loads(contents['Metadata/project_settings.config'])
    expected={'printer_model':'Bambu Lab A1','nozzle_diameter':['0.4'],'filament_type':['PLA','PETG'],
        'support_filament':'1','support_interface_filament':'2','support_top_z_distance':'0',
        'support_bottom_z_distance':'0','support_interface_top_layers':'2','support_interface_bottom_layers':'2',
        'support_bottom_interface_spacing':'0','support_interface_spacing':'0','raft_first_layer_expansion':'1.5',
        'support_on_build_plate_only':'0','enable_prime_tower':'1','flush_into_infill':'0','flush_into_objects':'0','flush_into_support':'0',
        'flush_volumes_matrix':['0','800','800','0'],
        'layer_height':'0.1','initial_layer_print_height':'0.1','top_shell_layers':'4','top_shell_thickness':'0.4',
        'bottom_shell_layers':'3','bottom_shell_thickness':'0.3','sparse_infill_density':'10%',
        'outer_wall_speed':['100'],'inner_wall_speed':['200'],'small_perimeter_speed':['35'],'small_perimeter_threshold':['6'],
        'top_surface_speed':['80'],'support_interface_speed':['80'],'prime_tower_max_speed':'120',
        'nozzle_temperature':['220','245'],'filament_max_volumetric_speed':['21','8'],
        'filament_flow_ratio':['0.98','0.94'],'filament_flush_temp':['245','245']}
    for k,v in expected.items():
        if settings.get(k)!=v:fail.append(f'setting {k}: {settings.get(k)} != {v}')
    max_native_error=0.
    actual_bounds=saved_mesh_bounds(contents)
    for i,el in enumerate(config.findall('object/part')):
        expected_bounds=np.array([a[i],b[i]])
        max_native_error=max(max_native_error,float(np.max(abs(actual_bounds[el.get('id')]-expected_bounds))))
    if max_native_error>0.02:fail.append(f'native position error {max_native_error}')
    totals,layers,bounds=deposited_paths(HERE/'stacked_kit.gcode.3mf')
    contacts=[];model_features=set(f for f,_ in totals)-{'Custom','Prime tower','Support','Support interface','Support transition'}
    model_by_z={};interface_by_z={}
    for z,segs in layers.items():
        model_by_z[z]=np.array([s[2:] for s in segs if s[0] in model_features and s[1]==0],dtype=float).reshape(-1,4)
        interface_by_z[z]=np.array([s[2:] for s in segs if s[0]=='Support interface' and s[1]==1],dtype=float).reshape(-1,4)
    for i,p in enumerate(parts):
        x0,y0,z0=a[i];x1,y1,z1=b[i]
        def hit_count(segs):
            # A support line can span several small parts with both endpoints
            # outside a footprint. Clip the entire segment, not its endpoint.
            if not len(segs):return 0
            ax,ay,bx,by=segs.T;dx,dy=bx-ax,by-ay;t0=np.zeros(len(segs));t1=np.ones(len(segs));valid=np.ones(len(segs),dtype=bool)
            for u,v in ((-dx,ax-x0+.25),(dx,x1+.25-ax),(-dy,ay-y0+.25),(dy,y1+.25-ay)):
                parallel=abs(u)<1e-12;valid&=~(parallel&(v<0));r=np.divide(v,u,out=np.zeros_like(v),where=~parallel)
                t0=np.where(u<0,np.maximum(t0,r),t0);t1=np.where(u>0,np.minimum(t1,r),t1)
            return int(np.count_nonzero(valid&(t0<=t1)))
        occupied_z=[z for z,segs in model_by_z.items() if z0-0.051<=z<=z1+0.151 and hit_count(segs)]
        model_hits=sum(hit_count(segs) for z,segs in model_by_z.items() if z in occupied_z)
        petg_hits=sum(hit_count(segs) for z,segs in interface_by_z.items() if z0-0.251<=z<=z0+0.051) if z0>0 else None
        if not model_hits:fail.append('missing model paths '+p['name'])
        if z0>0 and not petg_hits:fail.append('missing PETG below '+p['name'])
        base_error=min(occupied_z)-.1-z0 if occupied_z else None
        top_error=max(occupied_z)-z1 if occupied_z else None
        if base_error is not None and abs(base_error)>.051:fail.append('base layer quantization '+p['name']+' '+str(base_error))
        if top_error is not None and abs(top_error)>.051:fail.append('top layer quantization '+p['name']+' '+str(top_error))
        contacts.append({'part':p['name'],'tier':p['tier'],'base_z_mm':z0,'model_path_count':model_hits,'PETG_interface_path_count_under_part':petg_hits,
            'first_model_layer_z_mm':min(occupied_z) if occupied_z else None,'last_model_layer_z_mm':max(occupied_z) if occupied_z else None,
            'base_quantization_error_mm':base_error,'top_quantization_error_mm':top_error})
    support_volume=sum(v for (f,_),v in totals.items() if f in ('Support','Support interface','Support transition'))
    for feature,box in bounds.items():
        if feature!='Custom' and (min(box[:2])<.21 or max(box[2:])>255.79):fail.append('bed edge clearance '+feature+' '+str(box))
    # Strip cached G-code to make a native editable Studio project with presets.
    drop={n for n in contents if n.endswith(('.gcode','.gcode.md5')) or n in ('Metadata/slice_info.config','Metadata/filament_sequence.json')}
    relpath='Metadata/_rels/model_settings.config.rels'
    if relpath in contents:
        rel=ET.fromstring(contents[relpath])
        for e in list(rel):
            if '.gcode' in e.get('Target',''):rel.remove(e)
        contents[relpath]=ET.tostring(rel,encoding='utf-8',xml_declaration=True)
    project_config=ET.fromstring(contents['Metadata/model_settings.config'])
    for plate in project_config.findall('plate'):
        for meta in list(plate):
            if meta.get('key')=='gcode_file':plate.remove(meta)
    contents['Metadata/model_settings.config']=ET.tostring(project_config,encoding='utf-8',xml_declaration=True)
    with zipfile.ZipFile(HERE/'stacked_kit_project.3mf','w',zipfile.ZIP_DEFLATED) as z:
        for n,data in contents.items():
            if n not in drop:z.writestr(n,data)
    (HERE/'review').mkdir(exist_ok=True)
    for img in ('plate_1.png','top_1.png'):
        (HERE/'review'/img).write_bytes(contents['Metadata/'+img])
    trial=HERE/'trial-manifest.json'
    if trial.exists():native_names_and_project('separator_trial',json.loads(trial.read_text()))
    summary={'part_count':len(parts),'separate_named_meshes':len(leaves),'assembly_containers':1,'input_geometry_xml_sha256':geometry_hash,
        'bbox_min_mm':a.min(axis=0).tolist(),'bbox_max_mm':b.max(axis=0).tolist(),'minimum_stacked_bbox_separation_mm':min(separations),
        'native_position_max_error_mm':max_native_error,'slicer_settings_verified':expected,
        'support_deposited_volume_mm3':round(support_volume,2),'feature_volumes_mm3':{f'{f} / {("PLA","PETG")[t]}':round(v,2) for (f,t),v in totals.items()},
        'feature_xy_bounds_mm':bounds,'every_elevated_part_has_PETG_below':all(c['PETG_interface_path_count_under_part'] for c in contacts if c['base_z_mm']>0),
        'contacts':contacts,'failures':fail,
        'limitations':'Path checks confirm deposited support exists in each elevated part footprint; they do not prove continuous support over every point or physical release/adhesion. Bounding boxes are conservative; local undersides and process-specific tolerances still need the coupon.'}
    (HERE/'review/stack-verification.json').write_text(json.dumps(summary,indent=2))
    result_file=HERE/'jobs/stacked_kit/result.json'
    if not result_file.exists():result_file=HERE/'review/stacked_kit-slice.json'
    result=json.loads(result_file.read_text())
    plate=result['sliced_plates'][0]
    compare=json.loads((HERE/'review/placement-comparison.json').read_text())
    compare['optimized_independent_stacks']={k:plate[k] for k in ['main_predication','total_predication','filaments','filament_change_times']}
    (HERE/'review/placement-comparison.json').write_text(json.dumps(compare,indent=2))
    for name in ('stacked_kit','separator_trial'):
        result_file=HERE/'jobs'/name/'result.json'
        if not result_file.exists():result_file=HERE/'review'/(name+'-slice.json')
        r=json.loads(result_file.read_text())
        for p in r.get('sliced_plates',[]):
            p.pop('objects',None);p.pop('feature_type_times',None)
        (HERE/'review'/(name+'-slice.json')).write_text(json.dumps(r,indent=2))
    print(json.dumps({k:v for k,v in summary.items() if k not in ('contacts','feature_volumes_mm3','feature_xy_bounds_mm','slicer_settings_verified')},indent=2))
    if fail:raise SystemExit(1)

if __name__=='__main__':main()
